package com.example.windows.wristbalance;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends AppCompatActivity {

    Databasehelper openHelper;
    Button registerBtn,cancelBtn;
    EditText etusername,etpassword,etname,etemail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        openHelper = new Databasehelper(this);
         etusername = (EditText)findViewById(R.id.etusername);
         etpassword = (EditText)findViewById(R.id.etpassword);
         etname = (EditText)findViewById(R.id.etname);
         etemail = (EditText)findViewById(R.id.etemail);
         registerBtn = (Button)findViewById(R.id.registerBtn);
         cancelBtn = (Button)findViewById(R.id.cancelBtn);
         registerBtn.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {

                 String username = etusername.getText().toString();
                 String password = etpassword.getText().toString();
                 String name = etname.getText().toString();
                 String email = etemail.getText().toString();
                 if(username.matches("")||password.matches("")||name.matches("")||email.matches("")){
                     Toast.makeText(getApplicationContext(), "Register failed! Please make sure enter valid information!",Toast.LENGTH_LONG).show();

                 }else
                 {
                     openHelper.addUser(username,password,name,email);
                     Toast.makeText(getApplicationContext(), "Register successfully",Toast.LENGTH_LONG).show();
                     finish();
                 }
             }
         });

         cancelBtn.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 finish();
             }
         });

    }

}
