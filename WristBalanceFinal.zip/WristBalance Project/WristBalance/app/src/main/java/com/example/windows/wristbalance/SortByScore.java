package com.example.windows.wristbalance;

import java.util.Comparator;

public class SortByScore implements Comparator<History>
{
    public int compare(History a, History b)
    {
        return b.getScore()-a.getScore() ;
    }
}
