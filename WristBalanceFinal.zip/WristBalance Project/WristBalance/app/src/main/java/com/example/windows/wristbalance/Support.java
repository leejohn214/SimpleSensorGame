package com.example.windows.wristbalance;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class Support extends AppCompatActivity {

    private Button backBtn;
    private TextView sp_email, sp_phone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_support);
        backBtn = findViewById(R.id.backBtn);
        sp_email = findViewById(R.id.sp_email);
        sp_phone = findViewById(R.id.sp_phone);

        backBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        sp_email.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String mailto = "mailto:wristBalanceSupport@hotmail.com";


                Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
                emailIntent.setData(Uri.parse(mailto));

                try {
                    startActivity(emailIntent);
                } catch (ActivityNotFoundException e) {
                    e.printStackTrace();
                }
            }
        });

        sp_phone.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String phone = "+033636059";
                Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", phone, null));
                startActivity(intent);
            }
        });
    }
}
