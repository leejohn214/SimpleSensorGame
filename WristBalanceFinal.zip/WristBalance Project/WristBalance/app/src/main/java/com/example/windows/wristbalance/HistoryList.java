package com.example.windows.wristbalance;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class HistoryList extends AppCompatActivity {

    Databasehelper myDB;
    ListView playList;
    HistoryListAdapter customAdapter;
    ArrayList<History> arrayList;
    String userid = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        Spinner dropdown = findViewById(R.id.sortSpinner);
        playList=(ListView)findViewById(R.id.playList);

        String[] items = new String[]{"Sort by Date", "Sort by Score"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, items);
        dropdown.setAdapter(adapter);

        userid = getIntent().getStringExtra("id");

        myDB = new Databasehelper(this);
        arrayList = new ArrayList<>();
        arrayList = myDB.getData(userid);
        customAdapter = new HistoryListAdapter(this,arrayList);
        playList.setAdapter(customAdapter);

        dropdown.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                switch (position){
                    case 0: Collections.sort(arrayList,new SortByDate());
                            break;
                    case 1: Collections.sort(arrayList,new SortByScore());
                            break;
                }
                customAdapter.notifyDataSetChanged();
                playList.deferNotifyDataSetChanged();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {

            }

        });
    }

    public void cancel(View view){
        finish();
    }
}