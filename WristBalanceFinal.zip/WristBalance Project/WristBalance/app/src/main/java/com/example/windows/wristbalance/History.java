package com.example.windows.wristbalance;


public class History {
    private String date;
    private int score;

    public History(){

    }

    public History(String date, int score){
        this.setplayDate(date);
        this.setScore(score);
    }

    public String getplayDate() {
        return date;
    }

    public void setplayDate(String date) {
        this.date = date;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
