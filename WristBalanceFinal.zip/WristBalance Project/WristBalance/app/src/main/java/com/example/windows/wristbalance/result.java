package com.example.windows.wristbalance;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Date;

public class result extends AppCompatActivity {
    int score,highscore;
    String user_id;
    String playdate="";
    Date c=null;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView scoreLabel2 = (TextView)findViewById(R.id.scoreLabel2);
        TextView highScoreLabel = (TextView)findViewById(R.id.highScoreLabel);
        Button resulttoHis = (Button)findViewById(R.id.resulttoHis);
        Databasehelper myDB = new Databasehelper(this);

        score = getIntent().getIntExtra("SCORE",0);
        user_id = getIntent().getStringExtra("id");
        if(user_id.matches("0")){
            resulttoHis.setEnabled(false);
        }
        scoreLabel2.setText(score + "");

        SharedPreferences settings = getSharedPreferences("GAME_DATA",Context.MODE_PRIVATE);
        highscore = settings.getInt("HIGH_SCORE",0);

        if(score > highscore){
            highScoreLabel.setText("High Score : " + score);

            SharedPreferences.Editor editor = settings.edit();
            editor.putInt("HIGH_SCORE",score);
            editor.commit();
        }else {
            highScoreLabel.setText("High Score : " + highscore);;
        }
            c = Calendar.getInstance().getTime();
            SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
            playdate = df.format(c);
            myDB.addScore(score,playdate,user_id);
    }

    public void tryAgain(View view){
        Intent intent = new Intent(getApplicationContext(),PlayGame.class);
        intent.putExtra("id",user_id);
        startActivity(intent);

    }

    public void history(View view){
        Intent intent1 = new Intent(getApplicationContext(),HistoryList.class);
        intent1.putExtra("id",user_id);
        startActivity(intent1);
    }

    public void back(View view){
        finish();
    }


}
