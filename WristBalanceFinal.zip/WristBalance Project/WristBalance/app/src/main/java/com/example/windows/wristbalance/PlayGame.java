package com.example.windows.wristbalance;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

public class PlayGame extends AppCompatActivity implements SensorEventListener {


    TextView scoreLabel,startLabel,timerLabel;
    ImageView picman,ghost;
    SensorManager sm;
    Sensor accelerometer,magnometer;
    String userid="0";

    float[] accelOutput,magOutput,orientation = new float[3],startOrientation = null;
    long initTime,frameTime;
    int picmanX,picmanY,ghostX,ghostY;
    int score = 0;
    boolean start;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_play_game);
        scoreLabel = (TextView)findViewById(R.id.dateLabel);
        startLabel = (TextView)findViewById(R.id.startLabel);
        timerLabel = (TextView)findViewById(R.id.timerLabel);
        picman = (ImageView)findViewById(R.id.picman);
        ghost = (ImageView)findViewById(R.id.ghost);
        sm = (SensorManager)getSystemService(Context.SENSOR_SERVICE);
        accelerometer = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnometer = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        userid = getIntent().getExtras().getString("id");
        start = false;
        ghost.setX(500);
        ghost.setY(300);

        picmanX = 500;
        picmanY = 300;
        picman.setX(picmanX);
        picman.setY(picmanY);

        initTime = System.currentTimeMillis();
        frameTime = System.currentTimeMillis();

        scoreLabel.setText("Score : 0");
    }

    @Override
    protected void onPause(){
        super.onPause();
        sm.unregisterListener(this);
    }

    @Override
    protected void onResume(){
        super.onResume();
        sm.registerListener(this,accelerometer,SensorManager.SENSOR_DELAY_GAME);
        sm.registerListener(this,magnometer,SensorManager.SENSOR_DELAY_GAME);
    }

    @Override
    public void onSensorChanged(SensorEvent event){
        if(start) {

            DisplayMetrics dm = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(dm);

            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
                accelOutput = event.values;
            else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
                magOutput = event.values;
            if (accelOutput != null && magOutput != null) {
                float[] R = new float[9];
                float[] I = new float[9];
                boolean success = SensorManager.getRotationMatrix(R, I, accelOutput, magOutput);
                if (success) {
                    SensorManager.getOrientation(R, orientation);
                    if (startOrientation == null) {
                        startOrientation = new float[orientation.length];
                        System.arraycopy(orientation, 0, startOrientation, 0, orientation.length);
                    }
                }
            }

            int elapsedTime = (int) (System.currentTimeMillis() - frameTime);
            frameTime = System.currentTimeMillis();
            if (orientation != null && startOrientation != null) {
                float pitch = orientation[1] - startOrientation[1];
                float roll = orientation[2] - startOrientation[2];

                float xSpeed = 2 * roll * dm.widthPixels / 1000f;
                float ySpeed = pitch * dm.heightPixels / 1000f;

                picmanX += Math.abs(xSpeed * elapsedTime) > 5 ? xSpeed * elapsedTime : 0;
                picmanY -= Math.abs(ySpeed * elapsedTime) > 5 ? ySpeed * elapsedTime : 0;
            }

            FrameLayout frame = (FrameLayout) findViewById(R.id.frame);
            int frameHeight = frame.getHeight();
            int frameWidth = frame.getWidth();

            if (picmanX < 0)
                picmanX = 0;
            if (picmanX > frameWidth - picman.getWidth())
                picmanX = frameWidth - picman.getWidth();
            if (picmanY < 0)
                picmanY = 0;
            if (picmanY > frameHeight - picman.getHeight())
                picmanY = frameHeight - picman.getHeight();
            picman.setX(picmanX);
            picman.setY(picmanY);
            hitCheck();
        }
    }

    public void spawn(){
        FrameLayout frame = (FrameLayout)findViewById(R.id.frame);
        int frameHeight = frame.getHeight();
        int frameWidth = frame.getWidth();
        ghostX = (int)Math.floor(Math.random()*(frameWidth - ghost.getWidth()));
        ghostY = (int)Math.floor(Math.random()*(frameHeight - ghost.getHeight()));

        ghost.setX(ghostX);
        ghost.setY(ghostY);
    }

    public void hitCheck(){
        Rect rect1 = new Rect();
        picman.getHitRect(rect1);
        Rect rect2 = new Rect();
        ghost.getHitRect(rect2);

        if(Rect.intersects(rect1,rect2)){
            score += 10;
            scoreLabel.setText("Score : " + score);
            spawn();
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int i){

    }

    public boolean onTouchEvent(MotionEvent me){

        startLabel.setVisibility(View.GONE);
        start = true;
        countDownTimer.start();
        return true;

    }

    CountDownTimer countDownTimer = new CountDownTimer(30*1000,1000) {
        @Override
        public void onTick(long millisUntilFinished) {
            timerLabel.setText("Time Left : " + millisUntilFinished/1000 + " seconds");
        }

        @Override
        public void onFinish() {
            Intent intent = new Intent(getApplicationContext(),result.class);
            intent.putExtra("SCORE",score);
            intent.putExtra("id",userid);
            startActivity(intent);
            finish();
        }
    };
}
