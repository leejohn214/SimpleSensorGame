package com.example.windows.wristbalance;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Collections;


public class Databasehelper extends SQLiteOpenHelper {

        public static final String DATABASE_NAME = "wristbalance.db";
        public static final String TABLE_NAME = "user";
        public static final String TABLE_NAME2 = "score";
        public static final String COL_1 = "user_id";
        public static final String COL_2 = "Username";
        public static final String COL_3 = "Password";
        public static final String COL_4 = "Name";
        public static final String COL_5 = "Email";
        public static final String COL_6 = "score_id";
        public static final String COL_7 = "score";
        public static final String COL_8 = "date";

        public Databasehelper(Context context) {
            super(context, DATABASE_NAME, null, 1);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE " + TABLE_NAME + "(USER_ID INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE,Password TEXT,Name TEXT,Email TEXT ) ");
            db.execSQL("CREATE TABLE " + TABLE_NAME2 + "(SCORE_ID INTEGER PRIMARY KEY AUTOINCREMENT,Score INTEGER, Date TEXT,user_id INTEGER,FOREIGN KEY(user_id)REFERENCES user(USER_ID))");
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            db.execSQL("DROP TABLE IF EXISTS "+ TABLE_NAME);
            onCreate(db);
        }


        public boolean addScore(int score,String date,String id){
            SQLiteDatabase db = this.getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            int parserid = Integer.valueOf(id);
            contentValues.put(COL_7,score);
            contentValues.put(COL_8,date);
            contentValues.put(COL_1,parserid);

            long result = db.insert(TABLE_NAME2,null,contentValues);

            if(result == -1){
                return false;
            }else {
                return true;
            }
        }

    public void addUser(String username,String password,String name,String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(Databasehelper.COL_2,username);
        contentValues.put(Databasehelper.COL_3,password);
        contentValues.put(Databasehelper.COL_4,name);
        contentValues.put(Databasehelper.COL_5,email);

        db.insert(Databasehelper.TABLE_NAME,null, contentValues);
        db.close();
    }

    public ArrayList<History> getData(String id){
        ArrayList<History> list = new ArrayList<>();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME2 + " WHERE USER_ID = "+id, null);
        if(cursor.moveToFirst()){
            do{
                History his = new History();
                his.setScore(cursor.getInt(1));
                his.setplayDate(cursor.getString(2));
                list.add(his);
            }while (cursor.moveToNext());
        }
        return list;
    }

    }


