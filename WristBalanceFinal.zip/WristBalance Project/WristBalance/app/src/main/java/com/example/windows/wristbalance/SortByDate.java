package com.example.windows.wristbalance;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;

public class SortByDate implements Comparator<History> {
    DateFormat f = new SimpleDateFormat("MM-dd-yyyy");
    @Override
    public int compare(History a, History b){

        try {
            return f.parse(b.getplayDate()).compareTo(f.parse(a.getplayDate()));
        } catch (ParseException e) {
            throw new IllegalArgumentException(e);
        }
    }
}
