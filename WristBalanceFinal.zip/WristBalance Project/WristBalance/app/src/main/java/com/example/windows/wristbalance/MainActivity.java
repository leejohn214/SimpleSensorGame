package com.example.windows.wristbalance;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    Button playBtn, historyBtn, supportBtn, loginBtn,logoutBtn;
    TextView userLabel;
    String user_id="0";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
        playBtn = findViewById(R.id.playBtn);
        loginBtn = findViewById(R.id.loginBtn);
        supportBtn = findViewById(R.id.supportBtn);
        historyBtn = findViewById(R.id.historyBtn);
        userLabel = findViewById(R.id.userLabel);
        logoutBtn = findViewById(R.id.logoutBtn);

        playBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this,PlayGame.class);
                intent1.putExtra("id",user_id);
                startActivity(intent1);
            }
        });


        historyBtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent history = new Intent(MainActivity.this,HistoryList.class);
                history.putExtra("id",user_id);
                startActivity(history);
            }
        });

        supportBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent support = new Intent(MainActivity.this,Support.class);
                startActivity(support);
            }
        });

        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent login = new Intent(MainActivity.this,Login.class);
                startActivityForResult(login,11);
            }
        });

        logoutBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent logout = getIntent();
                finish();
                startActivity(logout);
            }
        });


    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode==11 && resultCode==RESULT_OK){
            user_id = data.getStringExtra("id");
            userLabel.setText("Welcome, "+data.getStringExtra("name"));
            logoutBtn.setVisibility(View.VISIBLE);
            loginBtn.setVisibility(View.INVISIBLE);
            historyBtn.setBackgroundResource(R.drawable.buttonstyle);
            historyBtn.setEnabled(true);
        }
    }




}
