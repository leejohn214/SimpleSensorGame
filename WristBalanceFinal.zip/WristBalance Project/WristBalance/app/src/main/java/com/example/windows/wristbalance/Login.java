package com.example.windows.wristbalance;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.database.Cursor;
import android.widget.TextView;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    SQLiteDatabase db;
    SQLiteOpenHelper openHelper;
    Cursor cursor;
    Button loginbtn;
    EditText etusername,etpassword;
    TextView registerLink;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        etusername = (EditText)findViewById(R.id.etusername);
        etpassword = (EditText)findViewById(R.id.etpassword);
        loginbtn = (Button)findViewById(R.id.cancelBtn);
        registerLink = (TextView)findViewById(R.id.registerLink) ;
        openHelper = new Databasehelper(this);
        db = openHelper.getReadableDatabase();

        loginbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = etusername.getText().toString();
                String password = etpassword.getText().toString();
                String name = "";
                String userid=null;
                cursor = db.rawQuery("Select *FROM " + Databasehelper.TABLE_NAME + " WHERE " + Databasehelper.COL_2 + "=? AND " + Databasehelper.COL_3 + "=?", new String[]{username, password});
                if (cursor != null){
                    if (cursor.getCount()> 0){
                        Toast.makeText(getApplicationContext(), "Login Successfully", Toast.LENGTH_SHORT).show();
                        while (cursor.moveToNext()){
                            userid = cursor.getString(0);
                            name = cursor.getString(3);
                        }
                        Intent intent = new Intent();
                        intent.putExtra("id",userid);
                        intent.putExtra("name",name);
                        setResult(RESULT_OK,intent);
                        finish();
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "Login Failed : Wrong Username or Password", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        registerLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Login.this,Register.class);
                startActivity(intent);
            }
        });
    }


}